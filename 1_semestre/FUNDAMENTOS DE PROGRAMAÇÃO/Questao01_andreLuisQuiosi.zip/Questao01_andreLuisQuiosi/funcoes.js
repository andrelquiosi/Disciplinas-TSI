function tabuada() {
    do{
      document.write(num, " * ", multiplicador, " = ", num * multiplicador,' <br>');
      multiplicador++;
    }while(multiplicador<=10){
        document.write("<hr>");
    }

}
package questao1;

public interface ItemOrcamento {

	public String getDescricao();

	public double getValor();

}

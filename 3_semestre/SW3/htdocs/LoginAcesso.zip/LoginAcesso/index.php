
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <<h1>Login de Acesso</h1>
        <form action="conexao.php" method="POST">
            Login:<input type="text" name="login" value="" /><br>
            Senha:<input type="password" name="senha" value="" /><br>
            <button type="submit" name="btn-entrar">Entrar </button>
            
        </form>
    </body>
</html>

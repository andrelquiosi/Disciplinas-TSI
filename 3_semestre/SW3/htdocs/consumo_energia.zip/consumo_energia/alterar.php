<?php

include("conexao.php");
$cliente = selecionarClienteId($_POST["id_cliente"]);

?>

<meta charset="UTF-8">

<a href="index.php"> Listar clientes </a>
<form name="dadosCliente" action="conexao.php" method="post">
    <table border="1">
        <tbody>
            <tr>
                <td>Nome</td>
                <td> <input type="text" name="nome" value='<?= $cliente["nome"] ?>'></td>
            </tr>
            <tr>
            <tr>
                <td>Sexo</td>
                <td> <input type="radio" name="sexo" value="F">Feminino
                    <input type="radio" name="sexo" value="M">Masculino
                </td>
            </tr>
            </tr>
            <tr>
                <td>Endereço</td>
                <td> <input type="text" name="endereco" value='<?= $cliente["endereco"] ?>'></td>
            </tr>
            <tr>
                <td>CEP</td>
                <td> <input type="text" name="cep" value='<?= $cliente["cep"] ?>'></td>
            </tr>
            <tr>
                <td>Bairro</td>
                <td> <input type="text" name="bairro" value='<?= $cliente["bairro"] ?>'></td>
            </tr>
            <tr>
                <td>CPF</td>
                <td> <input type="text" name="cpf" value='<?= $cliente["cpf"] ?>'></td>
            </tr>
            <tr>
                <td>Nascimento</td>
                <td> <input type="date" name="nascimento" value='<?= $cliente["nascimento"] ?>'></td>
            </tr>
            <tr>
                <td>Data de vencimento</td>
                <td> <input type="date" name="data_vencimento" value='<?= $cliente["data_vencimento"] ?>'></td>
            </tr>
            <tr>
                <td>Unidade consumidora</td>
                <td> <input type="text" name="unidade_consumidora" value='<?= $cliente["unidade_consumidora"] ?>'></td>
            </tr>
            <tr>
                <td>E-mail</td>
                <td><input type="text" name="email" value='<?= $cliente["email"] ?>'></td>
            </tr>
            <tr>
                <td>KWh</td>
                <td> <input type="text" name="kwh" value='<?= $cliente["kwh"] ?>'></td>
            </tr>
            <tr>
                <td>Valor total</td>
                <td> <input type="text" name="valor_total" value='<?= $cliente["valor_total"] ?>'></td>
            </tr>
            <tr>
                <td> <input type="hidden" name="acao" value="alterar"></td>
                <td> <input type="hidden" name="id_cliente" value='<?= $cliente["id_cliente"] ?>'></td>
                <td> <input type="submit" name="Enviar" value="enviar"></td>
            </tr>
        </tbody>
    </table>


</form>




</form>
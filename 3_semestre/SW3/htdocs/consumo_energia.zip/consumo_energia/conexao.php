<?php

if (isset($_POST["acao"])) {

    $erro;

    if ($_POST["acao"] == "inserir") {

        if (
            $_POST["nome"] == "" || $_POST["sexo"] == ""
            || $_POST["endereco"] == "" || $_POST["cep"] == ""
            || $_POST["bairro"] == "" || $_POST["cpf"] == ""
            || $_POST["nascimento"] == "" || $_POST["data_vencimento"] == ""
            || $_POST["unidade_consumidora"] == "" || $_POST["email"] == ""
            || $_POST["kwh"] == ""
            || $_POST["valor_total"] == ""
        ) {
            $erro = "Todos os campos são obrigatórios!";
        } else if ((!isset($_POST["email"]) || !filter_var($_POST["email"], FILTER_VALIDATE_EMAIL))) {
            $erro = 'O email informado é inválido.';
        } else {
            inserirCliente();
        }
    }

    if ($_POST["acao"] == "alterar") {
        if (
            $_POST["nome"] == "" || $_POST["sexo"] == ""
            || $_POST["endereco"] == "" || $_POST["cep"] == ""
            || $_POST["bairro"] == "" || $_POST["cpf"] == ""
            || $_POST["nascimento"] == "" || $_POST["data_vencimento"] == ""
            || $_POST["unidade_consumidora"] == "" || $_POST["email"] == ""
            || $_POST["kwh"] == ""
            || $_POST["valor_total"] == ""
        ) {
            $erro = "Todos os campos são obrigatórios!";
        } else if ((!isset($_POST["email"]) || !filter_var($_POST["email"], FILTER_VALIDATE_EMAIL))) {
            $erro = 'O email informado é inválido.';
        } else {
            alterarClientes();
        }
    }

    if ($_POST["acao"] == "excluir") {
        excluirClientes();
    }

    if ($erro) {
        echo "<h2>{$erro}</h2>
        <input type='button' value='Voltar' onclick='history.go(-1)'>";
    }
}

function abrirBanco()
{
    $conexao = new mysqli("localhost", "root", "", "consumo_energia");
    return $conexao;
}
function selecionarClienteId($id_cliente)
{
    $banco = abrirBanco();
    $sql = "SELECT * FROM cliente WHERE id_cliente=" . $id_cliente;
    $resultado = $banco->query($sql);
    $cliente = mysqli_fetch_assoc($resultado);
    return $cliente;
}

function inserirCliente()
{
    $banco = abrirBanco();
    $sql = "INSERT INTO cliente(nome,sexo,endereco,cep,bairro,cpf,nascimento,data_vencimento,unidade_consumidora,email,kwh,valor_total)" .
        "VALUES ('{$_POST["nome"]}','{$_POST["sexo"]}',
            '{$_POST["endereco"]}','{$_POST["cep"]}','{$_POST["bairro"]}',
            '{$_POST["cpf"]}','{$_POST["nascimento"]}','{$_POST["data_vencimento"]}',
            '{$_POST["unidade_consumidora"]}','{$_POST["email"]}','{$_POST["kwh"]}','{$_POST["valor_total"]}')";
    $banco->query($sql);
    $banco->close();
    voltarIndex();
}

function alterarClientes()
{
    $banco = abrirBanco();
    $sql = "UPDATE cliente SET nome='{$_POST["nome"]}',sexo='{$_POST["sexo"]}',
    endereco='{$_POST["endereco"]}',cep='{$_POST["cep"]}',bairro='{$_POST["bairro"]}',
    cpf='{$_POST["cpf"]}',nascimento='{$_POST["nascimento"]}',data_vencimento='{$_POST["data_vencimento"]}',
    unidade_consumidora='{$_POST["unidade_consumidora"]}',email = '{$_POST["email"]}',kwh='{$_POST["kwh"]}',valor_total='{$_POST["valor_total"]}'";
    $banco->query(($sql));
    $banco->close();
    voltarInserir();
}

function excluirClientes()
{
    $banco = abrirBanco();
    $sql = "DELETE FROM cliente WHERE id_cliente='{$_POST["id_cliente"]}'";
    $banco->query(($sql));
    $banco->close();
    voltarIndex();
}

function listarCliente()
{
    $banco = abrirBanco();
    $sql = "SELECT * FROM cliente ORDER BY nome";
    $resultado = $banco->query($sql);
    while ($row = mysqli_fetch_array($resultado)) {
        $grupo[] = $row;
    }
    return $grupo;
}

function voltarInserir()
{
    header("location:inserir.php");
}
function voltarIndex()
{
    header("location:index.php");
}

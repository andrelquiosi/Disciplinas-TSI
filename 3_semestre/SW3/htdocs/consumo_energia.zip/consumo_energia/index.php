<?php include 'conexao.php';
$grupo = listarCliente();
?>

<html>

<head>
    <meta charset="UTF-8">
    <title> Listando Clientes</title>
</head>

<body>

    <h1> Dados dos Clientes </h1>
    <table border="1">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Sexo</th>
                <th>Endereco</th>
                <th>CEP</th>
                <th>Bairro</th>
                <th>CPF</th>
                <th>Nascimento</th>
                <th>Data de Vencimento</th>
                <th>Unidade consumidora</th>
                <th>E-mail</th>
                <th>KWh</th>
                <th>Valor Total</th>
            </tr>
        </thead>

        <tbody>
            <?php foreach ($grupo as $cliente) : ?>
                <tr>

                    <td><?= $cliente["nome"] ?></td>
                    <td><?= $cliente["sexo"] ?></td>
                    <td><?= $cliente["endereco"] ?></td>
                    <td><?= $cliente["cep"] ?></td>
                    <td><?= $cliente["bairro"] ?></td>
                    <td><?= $cliente["cpf"] ?></td>
                    <td><?= $cliente["nascimento"] ?></td>
                    <td><?= $cliente["data_vencimento"] ?></td>
                    <td><?= $cliente["unidade_consumidora"] ?></td>
                    <td><?= $cliente["email"] ?></td>
                    <td><?= $cliente["kwh"] ?></td>
                    <td><?= $cliente["valor_total"] ?></td>
                    <th>
                        <form name="alterar" action="alterar.php" method="post">
                            <input type="hidden" name="id_cliente" value='<?= $cliente["id_cliente"] ?>' />
                            <input type="submit" name="Editar" value='editar' />
                        </form>
                    </th>
                    <th>
                    <form name="excluir" action="conexao.php" method="POST">
                        <input type="hidden" name="id_cliente" value='<?= $cliente["id_cliente"] ?>' />
                        <input type="hidden" name="acao" value='excluir' />
                        <input type="submit" name="Excluir" value='excluir' />
                    </form>
                    </th>
                </tr>

            <?php endforeach ?>
        </tbody>
    </table>
    <a href="inserir.php"> Adicionar Cliente </a>

</body>

</html>
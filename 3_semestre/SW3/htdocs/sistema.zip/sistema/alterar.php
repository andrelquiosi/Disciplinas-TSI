<?php

include("conexao.php");
$usuario = selecionarUsuarioId($_POST["id"]);

?>

<meta charset="UTF-8">

<a href="index.php"> Listar Usuarios </a>
<form name="dadosCliente" action="conexao.php" method="post">
    <table border="1">
        <tbody>
            <tr>
                <td>Nome</td>
                <td> <input type="text" name="nome" value='<?= $usuario["nome"] ?>'></td>
            </tr>
            <tr>
                <td>Nascimento</td>
                <td> <input type="date" name="nascimento" value='<?= $usuario["nascimento"] ?>'></td>
            </tr>
            <tr>
                <td>Endereço</td>
                <td> <input type="text" name="endereco" value='<?= $usuario["endereco"] ?>'></td>
            </tr>
            <tr>
                <td>Bairro</td>
                <td> <input type="text" name="bairro" value='<?= $usuario["bairro"] ?>'></td>
            </tr>
            <tr>
                <td>sexo</td>
                <td>
                    <input type="radio" name="sexo" value="M"> <?= ($usuario["sexo"] == "M") ? "checked" : null ?>
                    <label>Masculino</label>
                    <input type="radio" name="sexo" value="F"> <?= ($usuario["sexo"] == "F") ? "checked" : null ?>
                    <label>Feminino</label>
                </td>
            </tr>
            <tr>
                <td> <input type="hidden" name="acao" value="alterar"></td>
                <td> <input type="hidden" name="id" value='<?= $usuario["id"] ?>'></td>
                <td> <input type="submit" name="Enviar" value="enviar"></td>
            </tr>
        </tbody>
    </table>


</form>




</form>
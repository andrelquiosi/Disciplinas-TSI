<?php

if (isset($_POST["acao"])) {
    if ($_POST["acao"] == "inserir") {
        inserirUsuario();
    }
    if ($_POST["acao"] == "alterar") {
        alterarUsuarios();
    }
    if ($_POST["acao"] == "excluir") {
        excluirClientes();
    }
}


function abrirBanco()
{
    $conexao = new mysqli("localhost", "root", "", "cliente");
    return $conexao;
}

function inserirUsuario()
{
    $banco = abrirBanco();
    $sql = "INSERT INTO usuario(nome,nascimento,endereco,bairro,sexo)" .
        "VALUES ('{$_POST["nome"]}','{$_POST["nascimento"]}','{$_POST["endereco"]}','{$_POST["bairro"]}','{$_POST["sexo"]}')";
    $banco->query($sql);
    $banco->close();
    voltarInserir();
}

function listarUsuario()
{
    $banco = abrirBanco();
    $sql = "SELECT * FROM usuario ORDER BY nascimento";
    $resultado = $banco->query($sql);
    while ($row = mysqli_fetch_array($resultado)) {
        $grupo[] = $row;
    }
    return $grupo;
}

function excluirClientes(){
    $banco = abrirBanco();
    $sql = "DELETE FROM usuario WHERE id='{$_POST["id"]}'";
    $banco->query(($sql));
    $banco->close();
    voltarIndex();
}

function selecionarUsuarioId($id)
{
    $banco = abrirBanco();
    $sql = "SELECT * FROM usuario WHERE id=" . $id;
    $resultado = $banco->query($sql);
    $usuario = mysqli_fetch_assoc($resultado);
    return $usuario;
}

function alterarUsuarios()
{
    $banco = abrirBanco();
    $sql = "UPDATE usuario SET nome='{$_POST["nome"]}',nascimento='{$_POST["nascimento"]}',endereco='{$_POST["endereco"]}',bairro='{$_POST["bairro"]}',sexo='{$_POST["sexo"]}' WHERE id='{$_POST["id"]}'";
    $banco->query(($sql));
    $banco->close();
    voltarInserir();
}

function voltarInserir()
{
    header("location:inserir.php");
}
function voltarIndex()
{
    header("location:index.php");
}

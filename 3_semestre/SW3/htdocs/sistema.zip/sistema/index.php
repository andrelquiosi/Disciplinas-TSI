<?php include 'conexao.php';
$grupo = listarUsuario();
?>

<html>

<head>
    <meta charset="UTF-8">
    <title> listando usuarios</title>
</head>

<body>

    <h1> Dados do usuário </h1>
    <a href="inserir.php"> Adicionar Usuários </a>
    <table border="1">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Nascimento</th>
                <th>Endereco</th>
                <th>Bairro</th>
                <th>Sexo</th>
            </tr>
        </thead>

        <tbody>
            <?php foreach ($grupo as $usuario) : ?>
                <tr>
                    <td><?= $usuario["nome"] ?></td>
                    <td><?= $usuario["nascimento"] ?></td>
                    <td><?= $usuario["endereco"] ?></td>
                    <td><?= $usuario["bairro"] ?></td>
                    <td><?= $usuario["sexo"] ?></td>
                    <th>
                        <form name="alterar" action="alterar.php" method="post">
                            <input type="hidden" name="id" value='<?= $usuario["id"] ?>' />
                            <input type="submit" name="Editar" value='editar' />
                        </form>
                    </th>
                    <th>
                    <form name="excluir" action="conexao.php" method="POST">
                        <input type="hidden" name="id" value='<?= $usuario["id"] ?>' />
                        <input type="hidden" name="acao" value='excluir' />
                        <input type="submit" name="Excluir" value='excluir' />
                    </form>
                    </th>
                </tr>

            <?php endforeach ?>
        </tbody>
    </table>

</body>

</html>
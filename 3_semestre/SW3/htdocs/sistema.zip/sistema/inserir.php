<meta charset="UTF-8">

<a href="index.php"> Listar Usuarios </a>
<form name="dadosCliente" action="conexao.php" method="post">
    <table border="1">
        <tbody>
            <tr>
                <td>Nome</td>
                <td> <input type="text" name="nome" value=""></td>
            </tr>
            <tr>
                <td>Nascimento</td>
                <td> <input type="date" name="nascimento" value=""></td>
            </tr>
            <tr>
                <td>Endereço</td>
                <td> <input type="text" name="endereco" value=""></td>
            </tr>
            <tr>
                <td>Bairro</td>
                <td> <input type="text" name="bairro" value=""></td>
            </tr>
            <tr>
                <td>sexo</td>
                <td>
                    <input type="radio" name="sexo" value="M">
                    <label>Masculino</label>
                    <input type="radio" name="sexo" value="F">
                    <label>Feminino</label>
                </td>
            </tr>
            <tr>
                <td> <input type="hidden" name="acao" value="inserir"></td>
                <td> <input type="submit" name="Enviar" value="enviar"></td>
            </tr>
        </tbody>
    </table>


</form>




</form>
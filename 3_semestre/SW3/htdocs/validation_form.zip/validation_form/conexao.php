<?php

if (isset($_POST["acao"])) {
    // if ($_POST["acao"] == "inserir") {
    //     inserirValidation_form();
    // }
    // if ($_POST["acao"] == "alterar") {
    //     alterarValidation_forms();
    // }
    if ($_POST["acao"] == "excluir") {
        excluirValidation_form();
    }
}

function abrirBanco()
{
    $conexao = new mysqli("localhost", "root", "", "validation_form");
    return $conexao;
}
function selecionarValidation_formId($id_validation_form)
{
    $banco = abrirBanco();
    $sql = "SELECT * FROM validation_form WHERE id_validation_form=" . $id_validation_form;
    $resultado = $banco->query($sql);
    $validation_form = mysqli_fetch_assoc($resultado);
    return $validation_form;
}

function inserirValidation_form($name,$email,$gender,$comment,$website)
{
    $banco = abrirBanco();
    $sql = "INSERT INTO validation_form(name,email,website,comment,gender)" .
        "VALUES ($name,$email,$gender,$comment,$website)";
    $banco->query($sql);
    $banco->close();
    voltarIndex();
}

function alterarValidation_form($name,$email,$website,$comment,$gender)
{
    $banco = abrirBanco();
    $sql = "UPDATE validation_form SET name=$name, email=$email, website=$website, comment=$comment, gender=$gender";
    $banco->query(($sql));
    $banco->close();
    voltarInserir();
}

function excluirValidation_form()
{
    $banco = abrirBanco();
    $sql = "DELETE FROM validation_form WHERE id_validation_form='{$_POST["id_validation_form"]}'";
    $banco->query(($sql));
    $banco->close();
    voltarIndex();
}

function listarValidation_form()
{
    $banco = abrirBanco();
    $sql = "SELECT * FROM validation_form ORDER BY name";
    $resultado = $banco->query($sql);
    while ($row = mysqli_fetch_array($resultado)) {
        $grupo[] = $row;
    }
    return $grupo;
}

function voltarInserir()
{
    header("location:inserir.php");
}
function voltarIndex()
{
    header("location:index.php");
}

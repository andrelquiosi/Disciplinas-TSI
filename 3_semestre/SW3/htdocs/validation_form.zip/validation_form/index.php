<?php include 'conexao.php';
$grupo = listarValidation_form();
?>

<html>

<head>
    <meta charset="UTF-8">
    <title> Listando Comment</title>
</head>

<body>

    <h1> Comment </h1>
    <table border="1">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Email</th>
                <th>Website</th>
                <th>Comment</th>
                <th>Gender</th>
            </tr>
        </thead>

        <tbody>
            <?php foreach ($grupo as $cliente) : ?>
                <tr>

                    <td><?= $cliente["name"] ?></td>
                    <td><?= $cliente["email"] ?></td>
                    <td><?= $cliente["website"] ?></td>
                    <td><?= $cliente["comment"] ?></td>
                    <td><?= $cliente["gender"] ?></td>
                    <th>
                        <form name="alterar" action="alterar.php" method="post">
                            <input type="hidden" name="id_validation_form" value='<?= $cliente["id_validation_form"] ?>' />
                            <input type="submit" name="Editar" value='editar' />
                        </form>
                    </th>
                    <th>
                        <form name="excluir" action="conexao.php" method="POST">
                            <input type="hidden" name="id_validation_form" value='<?= $cliente["id_validation_form"] ?>' />
                            <input type="hidden" name="acao" value='excluir' />
                            <input type="submit" name="Excluir" value='excluir' />
                        </form>
                    </th>
                </tr>

            <?php endforeach ?>
        </tbody>
    </table>
    <a href="inserir.php"> Adicionar Cliente </a>

</body>

</html>
-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 01-Jul-2022 às 02:30
-- Versão do servidor: 10.4.24-MariaDB
-- versão do PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `bd_estacionamento`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `estadia`
--

CREATE TABLE `estadia` (
  `idEstadia` int(11) NOT NULL,
  `placaVeiculo` varchar(15) NOT NULL,
  `horarioEntrada` datetime NOT NULL DEFAULT current_timestamp(),
  `horarioSaida` datetime DEFAULT NULL,
  `valorDevido` double DEFAULT NULL,
  `idPatio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Acionadores `estadia`
--
DELIMITER $$
CREATE TRIGGER `Trigger_Liberar_vaga` AFTER UPDATE ON `estadia` FOR EACH ROW UPDATE
	patio p
   SET p.vagasDisponiveis = p.vagasDisponiveis +1
 WHERE NEW.horarioSaida IS NOT NULL
 AND p.idPatio = NEW.idPatio
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `Trigger_Reservar_vaga` AFTER INSERT ON `estadia` FOR EACH ROW UPDATE
	patio p
   SET p.vagasDisponiveis = p.vagasDisponiveis  - 1
 AND p.idPatio = NEW.idPatio
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `gerente`
--

CREATE TABLE `gerente` (
  `idGerente` int(11) NOT NULL,
  `cpfGerente` char(14) NOT NULL,
  `nomeGerente` varchar(40) NOT NULL,
  `valorSalario` double NOT NULL,
  `telefoneGerente` char(15) NOT NULL,
  `idPatio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `gerente`
--

INSERT INTO `gerente` (`idGerente`, `cpfGerente`, `nomeGerente`, `valorSalario`, `telefoneGerente`, `idPatio`) VALUES
(8, '123.123.123-13', 'João da Silva da Silva', 1500, '(45) 98999-1222', 3),
(9, '123.123.123-12', 'João da Silva', 1500, '(45) 98999-1231', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `patio`
--

CREATE TABLE `patio` (
  `idPatio` int(11) NOT NULL,
  `endereco` varchar(60) NOT NULL,
  `quantidadeVagas` int(11) NOT NULL,
  `vagasDisponiveis` int(11) NOT NULL,
  `valorHora` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `patio`
--

INSERT INTO `patio` (`idPatio`, `endereco`, `quantidadeVagas`, `vagasDisponiveis`, `valorHora`) VALUES
(1, 'Rua Opalão Azul 1337', 70, 70, 5),
(3, 'Avenida Brasil 1522', 10, 10, 33);

-- --------------------------------------------------------

--
-- Estrutura da tabela `perfil`
--

CREATE TABLE `perfil` (
  `idPerfil` int(11) NOT NULL,
  `nomePerfil` varchar(10) NOT NULL,
  `perfilAdministrador` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `perfil`
--

INSERT INTO `perfil` (`idPerfil`, `nomePerfil`, `perfilAdministrador`) VALUES
(1, 'publico', 0),
(2, 'admin', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `porteiro`
--

CREATE TABLE `porteiro` (
  `idPorteiro` int(11) NOT NULL,
  `cpfPorteiro` char(14) NOT NULL,
  `nomePorteiro` varchar(40) NOT NULL,
  `valorSalario` double NOT NULL,
  `telefonePorteiro` char(15) NOT NULL,
  `idPatio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `porteiro`
--

INSERT INTO `porteiro` (`idPorteiro`, `cpfPorteiro`, `nomePorteiro`, `valorSalario`, `telefonePorteiro`, `idPatio`) VALUES
(6, '123.123.123-12', 'Carlos Martins ', 1500, '(45) 15551-1223', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `idUsuario` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idPerfil` int(11) NOT NULL,
  `idPatio` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`idUsuario`, `name`, `email`, `password`, `idPerfil`, `idPatio`) VALUES
(7, 'admin', 'admin@admin.com', 'admin123456789', 2, 3);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `estadia`
--
ALTER TABLE `estadia`
  ADD PRIMARY KEY (`idEstadia`),
  ADD KEY `fk_idPatio_estadia` (`idPatio`);

--
-- Índices para tabela `gerente`
--
ALTER TABLE `gerente`
  ADD PRIMARY KEY (`idGerente`),
  ADD UNIQUE KEY `cpfGerente` (`cpfGerente`),
  ADD KEY `idPatio` (`idPatio`);

--
-- Índices para tabela `patio`
--
ALTER TABLE `patio`
  ADD PRIMARY KEY (`idPatio`);

--
-- Índices para tabela `perfil`
--
ALTER TABLE `perfil`
  ADD PRIMARY KEY (`idPerfil`);

--
-- Índices para tabela `porteiro`
--
ALTER TABLE `porteiro`
  ADD PRIMARY KEY (`idPorteiro`),
  ADD UNIQUE KEY `cpfPorteiro` (`cpfPorteiro`),
  ADD KEY `idPatio` (`idPatio`);

--
-- Índices para tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`idUsuario`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `fk_idPerfil_usuario` (`idPerfil`),
  ADD KEY `fk_idPatio_usuario` (`idPatio`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `estadia`
--
ALTER TABLE `estadia`
  MODIFY `idEstadia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de tabela `gerente`
--
ALTER TABLE `gerente`
  MODIFY `idGerente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `patio`
--
ALTER TABLE `patio`
  MODIFY `idPatio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `perfil`
--
ALTER TABLE `perfil`
  MODIFY `idPerfil` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `porteiro`
--
ALTER TABLE `porteiro`
  MODIFY `idPorteiro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `idUsuario` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `estadia`
--
ALTER TABLE `estadia`
  ADD CONSTRAINT `fk_idPatio_estadia` FOREIGN KEY (`idPatio`) REFERENCES `patio` (`idPatio`);

--
-- Limitadores para a tabela `gerente`
--
ALTER TABLE `gerente`
  ADD CONSTRAINT `idPatio` FOREIGN KEY (`idPatio`) REFERENCES `patio` (`idPatio`);

--
-- Limitadores para a tabela `porteiro`
--
ALTER TABLE `porteiro`
  ADD CONSTRAINT `fk_idPatio_porteiro` FOREIGN KEY (`idPatio`) REFERENCES `patio` (`idPatio`);

--
-- Limitadores para a tabela `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_idPatio_usuario` FOREIGN KEY (`idPatio`) REFERENCES `patio` (`idPatio`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_idPerfil_usuario` FOREIGN KEY (`idPerfil`) REFERENCES `perfil` (`idPerfil`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

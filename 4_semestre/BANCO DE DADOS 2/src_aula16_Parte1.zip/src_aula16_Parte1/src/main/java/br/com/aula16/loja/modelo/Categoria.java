package br.com.aula16.loja.modelo;

public enum Categoria {
	// Mapeamento no BD pela ordem 1, 2, 3...
	CELULARES,
	INFORMATICA,
	LIVROS;
}